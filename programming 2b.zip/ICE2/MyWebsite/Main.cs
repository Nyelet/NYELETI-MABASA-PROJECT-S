﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyWebsite
{
    public class Main
    {
        string SheepName;
        string SheepAge;
        string SheepWeight;
        string SheepGender;

        /*public string SheepName { get; set; }
        public string SheepAge { get; set; }
        public string SheepWeight { get; set; }
        public string SheepGender { get; set; }*/

    }

    //protected void 
}