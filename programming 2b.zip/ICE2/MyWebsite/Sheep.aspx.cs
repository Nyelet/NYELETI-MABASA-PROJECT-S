﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace MyWebsite
{
    public partial class Result : System.Web.UI.Page
    {
        public  string SheepName { get; set; }
        public string SheepAge { get; set; }
        public string SheepWeight { get; set; }
        public string SgeepGender { get; set; }
        public object MessageBox { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Data Source=RCPSSTDCR1PC36\SQLEXPRESS;Initial Catalog=records;Integrated Security=True";
            conn.Open();

            //exception handling code to alternate
            try
            {
                conn.Open();
                string query = "insert into Sheep VALUES(@SheepID, @SheepName, @SheepAge, @SheepWeight, @SheepGender)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@SheepName", TextBox1.Text);
                cmd.Parameters.AddWithValue("@SheepAge", TextBox2.Text);
                cmd.Parameters.AddWithValue("@SheepWeight", TextBox3.Text);
                cmd.Parameters.AddWithValue("@SheepGender", DropDownList1.Text.ToString());


                cmd.ExecuteNonQuery();
                conn.Close();
                //MessageBox.Show("Saved");
            }
            catch (Exception)
            {
                //MessageBox.Show("not saved");
            }
        }
    }
}