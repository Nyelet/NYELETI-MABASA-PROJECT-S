-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 18, 2018 at 11:04 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

DROP TABLE IF EXISTS `tbl_customer`;
CREATE TABLE IF NOT EXISTS `tbl_customer` (
  `Cust_ID` int(10) NOT NULL,
  `FName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  PRIMARY KEY (`Cust_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Cust_ID`, `FName`, `LName`) VALUES
(101, 'Tony', 'Meyer'),
(102, 'Hellen', 'Van Wyk'),
(103, 'Payne', 'James'),
(104, 'Robin', 'Thicke'),
(105, 'Jill', 'Smith'),
(106, 'Pamela', 'McKay'),
(107, 'Zola', 'Baloyi'),
(108, 'Themba', 'Zulu'),
(109, 'Karabo', 'Moloi'),
(1010, 'Njabulo', 'Ndlovu'),
(1011, 'Thando', 'Khomo'),
(1012, 'Kamo', 'Tshabalala'),
(1013, 'Luyanda', 'Zungu'),
(1014, 'Nicky', 'Marks'),
(1015, 'Thuso', 'Venda'),
(1016, 'Shaka', 'Khoza'),
(1017, 'Jack', 'Mabaso'),
(1018, 'Lwethu', 'Mbobo'),
(1019, 'Kly', 'Sims'),
(1020, 'Justin', 'Roberts'),
(1021, 'David', 'Botha'),
(1022, 'Zweli', 'Zuma'),
(1023, 'Jane', 'Frederick'),
(1024, 'Thomas', 'Gumbi'),
(1025, 'Skhumba', 'Hlophe'),
(1026, 'Thato', 'Mkhulu'),
(1027, 'Sipho', 'Ntuli'),
(1028, 'Mpumi', 'Grootboom'),
(1029, 'Siya', 'Mpama'),
(1030, 'Mandla', 'Moya');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_items`
--

DROP TABLE IF EXISTS `tbl_items`;
CREATE TABLE IF NOT EXISTS `tbl_items` (
  `item_ID` int(10) NOT NULL,
  `order_ID` int(10) NOT NULL,
  `item_Name` varchar(50) NOT NULL,
  PRIMARY KEY (`item_ID`),
  KEY `fk_tbl_items_tbl_orders` (`order_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_items`
--

INSERT INTO `tbl_items` (`item_ID`, `order_ID`, `item_Name`) VALUES
(11, 1, 'deodorant'),
(12, 2, 'shower gel'),
(13, 3, 'hair food'),
(14, 4, 'face wash'),
(15, 5, 'glasses'),
(16, 6, 'plastic plates'),
(17, 7, 'muffins'),
(18, 8, 'apples'),
(19, 9, 'pinapples'),
(20, 10, 'ice cream'),
(21, 11, 'bread'),
(22, 12, 'chocolate cake'),
(23, 13, 'cool drinks'),
(24, 14, 'tea'),
(25, 15, 'coffee'),
(26, 16, 'chips'),
(27, 17, 'milk'),
(28, 18, 'bath soap'),
(29, 19, 'toothpaste'),
(30, 20, 'potatos'),
(31, 21, 'washing powder'),
(32, 22, 'juice'),
(33, 23, 'rice'),
(34, 24, 'cereal'),
(35, 25, 'green beans'),
(36, 26, 'butter'),
(37, 27, 'drum sticks'),
(38, 28, 'fish'),
(39, 29, 'body butter'),
(40, 30, 'sweets');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_itemsold`
--

DROP TABLE IF EXISTS `tbl_itemsold`;
CREATE TABLE IF NOT EXISTS `tbl_itemsold` (
  `item_ID` int(10) NOT NULL,
  `item_Name` varchar(50) NOT NULL,
  KEY `fk_tbl_itemsold_tbl_items` (`item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_itemsold`
--

INSERT INTO `tbl_itemsold` (`item_ID`, `item_Name`) VALUES
(11, 'deodorant'),
(12, 'shower gel'),
(13, 'hair food'),
(14, 'face wash'),
(15, 'glasses'),
(16, 'plastic plates'),
(17, 'muffins'),
(18, 'apples'),
(19, 'pinapples'),
(20, 'ice cream'),
(21, 'bread'),
(22, 'chocolate cake'),
(23, 'cool drinks'),
(24, 'tea'),
(25, 'coffee'),
(26, 'chips'),
(27, 'milk'),
(28, 'bath soap'),
(29, 'toothpaste'),
(30, 'potatos'),
(31, 'washing powder'),
(32, 'juice'),
(33, 'rice'),
(34, 'cereal'),
(35, 'green beans'),
(36, 'butter'),
(37, 'drum sticks'),
(38, 'fish'),
(39, 'body butter'),
(40, 'sweets');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `order_ID` int(10) NOT NULL,
  `Cust_ID` int(10) NOT NULL,
  `item_ID` int(10) NOT NULL,
  `item_Name` varchar(50) NOT NULL,
  PRIMARY KEY (`order_ID`),
  KEY `fk_tbl_orders_tbl_customer` (`Cust_ID`),
  KEY `fk_tbl_orders_tbl_items` (`item_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`order_ID`, `Cust_ID`, `item_ID`, `item_Name`) VALUES
(1, 101, 11, 'deodorant'),
(2, 102, 12, 'shower gel'),
(3, 103, 13, 'hair food'),
(4, 104, 14, 'face wash'),
(5, 105, 15, 'glasses'),
(6, 106, 16, 'plastic plates'),
(7, 107, 17, 'muffins'),
(8, 108, 18, 'apples'),
(9, 109, 19, 'pinapples'),
(10, 1010, 20, 'ice cream'),
(11, 1011, 21, 'bread'),
(12, 1012, 22, 'chocolate cake'),
(13, 1013, 23, 'cool drinks'),
(14, 1014, 24, 'tea'),
(15, 1015, 25, 'coffee'),
(16, 1016, 26, 'chips'),
(17, 1017, 27, 'milk'),
(18, 1018, 28, 'bath soap'),
(19, 1019, 29, 'toothpaste'),
(20, 1020, 30, 'potatos'),
(21, 1021, 31, 'washing powder'),
(22, 1022, 32, 'juice'),
(23, 1023, 33, 'rice'),
(24, 1024, 34, 'cereal'),
(25, 1025, 35, 'green beans'),
(26, 1026, 36, 'butter'),
(27, 1027, 37, 'drum sticks'),
(28, 1028, 38, 'fish'),
(29, 1029, 39, 'body butter'),
(30, 1030, 40, 'sweets');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_items`
--
ALTER TABLE `tbl_items`
  ADD CONSTRAINT `fk_tbl_items_tbl_orders` FOREIGN KEY (`order_ID`) REFERENCES `tbl_order` (`order_ID`);

--
-- Constraints for table `tbl_itemsold`
--
ALTER TABLE `tbl_itemsold`
  ADD CONSTRAINT `fk_tbl_itemsold_tbl_items` FOREIGN KEY (`item_ID`) REFERENCES `tbl_items` (`item_ID`);

--
-- Constraints for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD CONSTRAINT `fk_tbl_orders_tbl_customer` FOREIGN KEY (`Cust_ID`) REFERENCES `tbl_customer` (`Cust_ID`),
  ADD CONSTRAINT `fk_tbl_orders_tbl_items` FOREIGN KEY (`item_ID`) REFERENCES `tbl_items` (`item_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
